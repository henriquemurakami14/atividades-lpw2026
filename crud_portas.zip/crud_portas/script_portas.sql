/* TABELA sistemas */
CREATE TABLE sistemas (
  id int AUTO_INCREMENT NOT NULL,
  nome varchar(20) NOT NULL,
  CONSTRAINT pk_sistemas PRIMARY KEY (id)
);

/* INSERTs sistemas */
INSERT INTO sistemas (nome) VALUES ('GIRO');
INSERT INTO sistemas (nome) VALUES ('PIVOTANTE');
INSERT INTO sistemas (nome) VALUES ('CORRER');

/* TABELA materiais */
CREATE TABLE materiais (
  id int AUTO_INCREMENT NOT NULL,
  nome varchar(20) NOT NULL,
  CONSTRAINT pk_materiais PRIMARY KEY (id)
);

/* INSERTs materiais */
INSERT INTO materiais (nome) VALUES ('ACM');
INSERT INTO materiais (nome) VALUES ('MDF');
INSERT INTO materiais (nome) VALUES ('ALUMÍNIO');

/* TABELA portas */
CREATE TABLE portas (
  id int AUTO_INCREMENT NOT NULL,
  modelo varchar(100) NOT NULL,
  cor varchar(50) NOT NULL,
  acessorio varchar(100) NOT NULL,
  id_sistema int NOT NULL,
  id_material int NOT NULL,
  CONSTRAINT pk_portas PRIMARY KEY (id)
);

ALTER TABLE portas ADD CONSTRAINT fk_sistema FOREIGN KEY (id_sistema) REFERENCES sistemas (id);
ALTER TABLE portas ADD CONSTRAINT fk_material FOREIGN KEY (id_material) REFERENCES materiais (id);