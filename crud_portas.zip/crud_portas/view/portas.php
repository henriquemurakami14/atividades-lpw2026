<?php

require_once("../../util/Connection.php");

$conn = Connection::getConnection();
print_r($conn);

?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cadastro de Portas</title>
</head>
<body>
    <h1>Cadastro de Portas</h1>
</body>
</html>