<?php
require_once(__DIR__ . "/../../util/config.php");
?>

<style>
    .navbar-cielo {
        background-color: #12233d; 
        padding: 0.75rem 1.5rem;
    }

    .navbar-cielo .navbar-brand {
        color: #ffffff;
        font-weight: 700;
        letter-spacing: 1px;
        text-transform: uppercase;
        font-size: 1.15rem;
    }

    .navbar-cielo .navbar-brand:hover {
        color: #a9c3de;
    }

    .navbar-cielo .nav-link {
        color: #e4e9ef;
        font-weight: 500;
        letter-spacing: 0.5px;
        transition: color 0.2s ease;
    }

    .navbar-cielo .nav-link:hover,
    .navbar-cielo .nav-link:focus {
        color: #ffffff;
    }

    .navbar-cielo .nav-link.dropdown-toggle::after {
        vertical-align: middle;
    }

    .navbar-cielo .dropdown-menu {
        background-color: #ffffff;
        border: none;
        border-top: 3px solid #1e3a5f;
        box-shadow: 0 6px 16px rgba(0, 0, 0, 0.15);
    }

    .navbar-cielo .dropdown-item {
        color: #12233d;
        font-weight: 500;
    }

    .navbar-cielo .dropdown-item:hover,
    .navbar-cielo .dropdown-item:focus {
        background-color: #f0efe9; 
        color: #12233d;
    }

    .navbar-cielo .navbar-toggler {
        border-color: rgba(255, 255, 255, 0.4);
    }

    .navbar-cielo .navbar-toggler-icon {
        filter: invert(1);
    }
</style>

<nav class="navbar navbar-expand-md navbar-cielo px-3">

    <!-- Logo -->
    <a class="navbar-brand" href="<?= BASE_URL ?>/index.php">Cielo Aberturas</a>
    
    <!-- Botão para Dispositivos menores -->
    <button class="navbar-toggler" type="button"
        data-bs-toggle="collapse" data-bs-target="#navSite">
        <span class="navbar-toggler-icon"></span>
    </button>

    <!-- Itens do menu -->
    <div class="collapse navbar-collapse" id="navSite">
    
        <ul class="navbar-nav ms-auto">

            <li class="nav-item">
                <a class="nav-link" href="<?= BASE_URL ?>/index.php">Home</a>
            </li>

            <li class="nav-item dropdown">
                <a class="nav-link dropdown-toggle" href="#" id="navDropDown" data-bs-toggle="dropdown">Catálogo</a>
                <div class="dropdown-menu">
                    <a class="dropdown-item" href="<?= BASE_URL ?>/view/portas/listar.php">Portas</a>
                </div>
            </li>

            <li class="nav-item">
                <a class="nav-link" href="#">Sobre</a>
            </li>
        </ul>
    </div>

</nav>