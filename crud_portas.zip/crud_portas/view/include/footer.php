<style>
    .footer-cielo {
        background-color: #12233d;
        border-top: 3px solid #1e3a5f;
    }

    .footer-cielo p,
    .footer-cielo .footer-text {
        color: #cfd8e3;
        font-size: 0.9rem;
        letter-spacing: 0.3px;
        margin: 0;
    }

    .footer-cielo a {
        color: #ffffff;
        font-weight: 600;
        text-decoration: none;
        transition: color 0.2s ease;
    }

    .footer-cielo a:hover {
        color: #a9c3de;
        text-decoration: underline;
    }
</style>

<footer class="footer-cielo mt-3">
    <div class="text-center p-4 footer-text">
        &copy; <?= date("Y") ?> Copyright:
        <a href="https://www.instagram.com/cieloaberturas" target="_blank" rel="noopener">Cielo Aberturas</a>
    </div>
</footer>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/js/bootstrap.bundle.min.js" integrity="sha384-FKyoEForCGlyvwx9Hj09JcYn3nv7wiPVlz7YYwJrWVcXK/BmnVDxM+D2scQbITxI" crossorigin="anonymous"></script>
</body>
</html>