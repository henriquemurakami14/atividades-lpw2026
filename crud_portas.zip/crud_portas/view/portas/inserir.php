<?php

require_once(__DIR__ . "/../../model/Porta.php");
require_once(__DIR__ . "/../../model/Material.php");
require_once(__DIR__ . "/../../model/Sistema.php");
require_once(__DIR__ . "/../../controller/PortaController.php");

$msgErro = "";
$msgSucesso = "";
$porta = NULL;

if (isset($_POST['modelo'])) { // verifica se foi enviado algo no POST
    
    // Pequenas validações como se está vazio e tirando os espaços extras
    $modelo = trim($_POST['modelo']) ? trim($_POST['modelo']): null;
    $cor = trim($_POST['cor']) ? trim($_POST['cor']): null;
    $acessorio = trim($_POST['acessorio']) ? trim($_POST['acessorio']): null;
    $idMaterial = trim($_POST['material']) ? trim($_POST['material']): null;
    $idSistema = trim($_POST['sistema']) ? trim($_POST['sistema']): null;

    // Criações dos Objetos
    $porta = new Porta();
    $porta->setModelo($modelo);
    $porta->setCor($cor);
    $porta->setAcessorio($acessorio);
    $porta->setId(0);

    $material = new Material();
    $material->setId($idMaterial);
    $porta->setMaterial($material);

    $sistema = new Sistema();
    $sistema->setId($idSistema);
    $porta->setSistema($sistema);

    $portaCont = new PortaController();
    $erros = $portaCont->inserir($porta); // Pega o erros do Controller

    if (! empty ($erros)) { // Valida se tem erros
        $msgErro = implode("<br>", $erros); // Cria os erros
    } else {
        $msgSucesso = "Enviado com sucesso!";
    }
}

require_once(__DIR__ . "/form.php");

?>