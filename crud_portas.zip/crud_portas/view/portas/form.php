<?php

require_once(__DIR__."/../include/header.php");
require_once(__DIR__ . "/../include/menu.php");
require_once(__DIR__."/../../controller/MaterialController.php");
require_once(__DIR__."/../../controller/SistemaController.php");

$materialController = new MaterialController();
$materiais = $materialController->listar(); // Lista para mostrar no select os materiais

$sistemaController = new SistemaController();
$sistemas = $sistemaController->listar(); // Lista para mostrar no select os sistemas

?>

<!-- Ele verifica se a $porta tem valor, se tiver retorna inserir, senao é o alterar -->
<h3><?= $porta && $porta->getId() > 0 ? "Alterar" : "Inserir" ?> Porta</h3> 

<div class="row">
    <div class="col-6">

        <!-- Exibe mensagem de sucesso caso form enviado -->
        <?php if (isset($_GET['sucesso'])): ?>
            <div class="alert alert-success mt-3">Porta salva com sucesso!</div> 
        <?php endif; ?>

        <form action="" method="POST">

            <div>
                <label class="form-label" for="txt-modelo">Modelo: </label>
                <input class="form-control" type="text" id="txt-modelo" placeholder="Informe o modelo..." name="modelo" value="<?= $porta != null ? $porta->getModelo() : '' ?>">
            </div>

            <div>
                <label class="form-label" for="txt-cor">Cor: </label>
                <input class="form-control" type="text" id="txt-cor" placeholder="Informe a cor..." name="cor" value="<?= $porta != null ? $porta->getCor() : '' ?>">
            </div>

            <div>
                <label class="form-label" for="txt-acessorio">Acessório: </label>
                <input class="form-control" type="text" id="txt-acessorio" placeholder="Informe o acessório..." name="acessorio" value="<?= $porta != null ? $porta->getAcessorio() : '' ?>">
            </div>

            <div>
                <label class="form-label" for="sel-material">Material: </label>
                <select class="form-select" name="material" id="sel-material">
                    <option value="">Escolher uma opção...</option>

                    <?php foreach ($materiais as $material): ?>
                        <option value="<?= $material->getId() ?>"
                        <?php
                            if($porta && $porta->getMaterial()->getId() == $material->getId())
                                print "selected";
                        ?>
                        >
                        <?= $material->getNome() ?></option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div>
                <label class="form-label" for="sel-sistema">Sistema: </label>
                <select class="form-select" name="sistema" id="sel-sistema">
                    <option value="">Escolher uma opção...</option>

                    <?php foreach ($sistemas as $sistema): ?>
                        <option value="<?= $sistema->getId() ?>"
                        <?php
                            if($porta && $porta->getSistema()->getId() == $sistema->getId())
                                print "selected";
                        ?>
                        >
                        <?= $sistema->getNome() ?></option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div>
                <input type="hidden" name="id" value="<?= $porta ? $porta->getId() : 0 ?>">
            </div>

            <div>
                <button class="btn btn-success mt-3" type="submit">Salvar</button>
            </div>
            
        </form>

    </div>

    <div class="col-6">

        <?php if(!empty($msgErro)): ?>
            <div class="alert alert-danger mt-3">
                <?= $msgErro ?>
            </div>
        <?php endif; ?>

        <?php if(!empty($msgSucesso)): ?>
            <div class="alert alert-success mt-3">
                <?= $msgSucesso ?>
            </div>
        <?php endif; ?>
        
    </div>
    
    
</div>

    <a class="btn btn-primary mt-3" href="listar.php">Voltar</a>

<?php require_once(__DIR__."/../include/footer.php"); ?>