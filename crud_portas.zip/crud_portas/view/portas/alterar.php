<?php

require_once(__DIR__ . "/../../controller/PortaController.php");

$msgErro = "";
$porta = NULL;
$portaCont = new PortaController();

if (isset($_POST['modelo'])) { // verifica se foi enviado algo no POST

    // Pequenas validações como se está vazio e tirando os espaços extras
    $id = $_POST['id'];
    $modelo = trim($_POST['modelo']) ? trim($_POST['modelo']): null;
    $cor = trim($_POST['cor']) ? trim($_POST['cor']): null;
    $acessorio = trim($_POST['acessorio']) ? trim($_POST['acessorio']): null;
    $idSistema = trim($_POST['sistema']) ? trim($_POST['sistema']): null;
    $idMaterial = trim($_POST['material']) ? trim($_POST['material']): null;

    // Criações dos Objetos
    $porta = new Porta();
    $porta->setModelo($modelo);
    $porta->setCor($cor);
    $porta->setAcessorio($acessorio);

    $sistema = new Sistema();
    $sistema->setId($idSistema);
    $porta->setSistema($sistema);

    $material = new Material();
    $material->setId($idMaterial);
    $porta->setMaterial($material);

    $porta->setId($id);

    $erros = $portaCont->alterar($porta); // Pega o erros do Controller

    if (empty($erros)) { // Valida se tem erros
        header("location: listar.php"); 
    } else {
        $msgErro = implode("<br>", $erros); // Cria os erros
    }

} else {
    // Verificação para ver se vc nao está alterando algo que n existe

    $id = 0;
    if (isset($_GET['id'])) { // Verifica se está setado
        $id = $_GET['id'];
    }

    $porta = $portaCont->buscarPorId($id);

    if (! $porta) {
        print "ID de porta inválido!<br>";
        print "<a href='listar.php'>Voltar</a>";
        exit;
    }

}
    
require_once(__DIR__ . "/form.php");

