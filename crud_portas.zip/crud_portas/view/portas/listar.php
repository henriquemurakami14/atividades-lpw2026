<?php

require_once(__DIR__ . "/../../controller/PortaController.php");

$portaCont = new PortaController();
$listaPortas = $portaCont->listar();

require_once(__DIR__ . "/../include/header.php");
require_once(__DIR__ . "/../include/menu.php");
?>

<h3>Listagem de Portas</h3>

<a href="inserir.php" class="btn btn-primary m-3">Inserir</a>

<table class="table table-striped" border='1'>
    <tr>
        <th>ID</th>
        <th>MODELO</th>
        <th>COR</th>
        <th>ACESSÓRIO</th>
        <th>MATERIAL</th>
        <th>SISTEMA</th>
        <th>ALTERAR</th>
        <th>EXCLUIR</th>
    </tr>

    <?php foreach ($listaPortas as $porta): ?>
        <tr>
            <td><?= $porta->getId() ?></td>
            <td><?= $porta->getModelo() ?></td>
            <td><?= $porta->getCor() ?></td>
            <td><?= $porta->getAcessorio() ?></td>
            <td><?= $porta->getMaterial()->getNome() ?></td>
            <td><?= $porta->getSistema()->getNome() ?></td>
            <td>
                <a href="alterar.php?id=<?= $porta->getId() ?>">Alterar</a>
            </td>
            <td>
                <a onclick="return confirm('Você tem certeza que deseja excluir esse item?')" href="excluir.php?id=<?= $porta->getId() ?>" >Excluir</a>
            </td>
        </tr>
    <?php endforeach; ?>

    </table>

    

<?php
require_once(__DIR__ . "/../include/footer.php");
?>

