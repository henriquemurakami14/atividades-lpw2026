<?php

require_once(__DIR__ . "/../../controller/PortaController.php");

if(isset($_GET['id'])) { // Ele verifica se o ID está setado
    $id = $_GET['id'];
    $portaCont = new PortaController();
    $erro = $portaCont->excluir($id);  // se tiver algum erro, ele retorna o erro

    if(! $erro) {
        header("location: listar.php");  
    } else {
        echo $erro;
        echo "<br><a href='listar.php'>Voltar</a>";
    }
    
} else {
    echo "ID de porta não informado!<br>";
    echo "<a href='listar.php'>Voltar</a>";
}



