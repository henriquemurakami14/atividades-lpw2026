<?php

require_once(__DIR__."/../dao/SistemaDAO.php");

class SistemaController {
    public function listar() {
        $sistemaDAO = new SistemaDAO;
        return $sistemaDAO->listar();
    }
}