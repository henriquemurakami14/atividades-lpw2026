<?php

require_once(__DIR__ . "/../dao/PortaDAO.php");
require_once(__DIR__ . "/../service/PortaService.php");

class PortaController {

    private PortaDAO $portaDAO;
    private PortaService $portaService;

    public function __construct() {
        $this->portaDAO = new PortaDAO();
        $this->portaService = new PortaService();
    }

    public function listar() {
        return $this->portaDAO->listar();
    }

    public function inserir($porta) {
        $erros = $this->portaService->validar($porta);   

        if (empty($erros)) {
            $erroDAO = $this->portaDAO->inserir($porta);
            if ($erroDAO) {
                array_push($erros, $erroDAO);          
            }
        }
        return $erros;
    }

    public function buscarPorId(int $id) {
        return $this->portaDAO->buscarPorId($id);
    }

    public function excluir(int $id) {
        $erroDAO = $this->portaDAO->excluir($id);

        return $erroDAO;
    }

    public function alterar($porta) {
        $erros = $this->portaService->validar($porta);

        if (empty($erros)) {
            $erroDAO = $this->portaDAO->alterar($porta);
            if ($erroDAO) {
                array_push($erros, $erroDAO);
            }

            return $erros;
        }
    }

}