<?php

require_once(__DIR__."/../dao/MaterialDAO.php");

class MaterialController {
    public function listar() {
        $materialDAO = new MaterialDAO;
        return $materialDAO->listar();
    }
}