<?php
// adicionar mais validações
require_once(__DIR__ . "/../model/Porta.php");

// Validação do Form
class PortaService {

    public function validar(Porta $porta) {
        $erros = array();

        if(!$porta->getModelo())
            array_push($erros, "Informe o modelo!");
        
        if(! $porta->getCor())
            array_push($erros, "Informe a cor!");

        if(! $porta->getAcessorio())
            array_push($erros, "Informe se a porta tem acessório!");

        if(! $porta->getSistema()->getId())
            array_push($erros, "Informe o sistema!");

        if(! $porta->getMaterial()->getId())
            array_push($erros, "Informe o material!");

        return $erros;
    }

}