<?php

require_once(__DIR__ . "/../util/Conexao.php");
require_once(__DIR__ . "/../model/Porta.php");
require_once(__DIR__ . "/../model/Sistema.php");
require_once(__DIR__ . "/../model/Material.php");

class PortaDAO {

    public function listar() {
        $sql = "SELECT p.*, m.nome nome_material, s.nome nome_sistema 
                FROM portas p 
                JOIN materiais m ON (m.id = p.id_material)
                JOIN sistemas s ON (s.id = p.id_sistema)";

        $conn = Connection::getConnection();
        $stm = $conn->prepare($sql);
        $stm->execute();
        $dados = $stm->fetchAll();
        return $this->map($dados);
    }

    public function inserir(Porta $porta) {
        try {
    
        $sql = "INSERT INTO portas (modelo, cor, acessorio, id_sistema, id_material) VALUES (:modelo, :cor, :acessorio, :id_sistema, :id_material)";

        $conn = Connection::getConnection();
        $stm = $conn->prepare($sql);
        $stm->bindValue("modelo", $porta->getModelo());
        $stm->bindValue("cor", $porta->getCor());
        $stm->bindValue("acessorio", $porta->getAcessorio());
        $stm->bindValue("id_sistema", $porta->getSistema()->getId());
        $stm->bindValue("id_material", $porta->getMaterial()->getId());
        $stm->execute();
        return "";

        } catch (PDOException $e) {
            $erro = "Erro ao salvar a porta. Tente novamente.";
            if(AMB_DEV)
                $erro .= "<br>" . $e->getMessage();
            return $erro;
        }

    }

    public function buscarPorId(int $id): ?Porta {
        $sql = "SELECT p.*, m.nome nome_material, s.nome nome_sistema
        FROM portas p 
        JOIN materiais m ON (m.id = p.id_material)
        JOIN sistemas s ON (s.id = p.id_sistema) 
        WHERE p.id = ?";

        $conn = Connection::getConnection();
        $stm = $conn->prepare($sql);
        $stm->execute([$id]);

        $dados = $stm->fetchAll();
        $portas = $this->map($dados);   

        if (! empty($portas)) {
            return $portas[0];
        } else {
            return null;
        }
    }

    public function alterar(Porta $porta) {
        try {
            $sql = "UPDATE portas SET modelo = ?, cor = ?, acessorio = ?, id_sistema = ?, id_material = ? WHERE id = ?";

            $conn = Connection::getConnection();
            $stm = $conn->prepare($sql);
            $stm->execute([$porta->getModelo(), $porta->getCor(), $porta->getAcessorio(), $porta->getSistema()->getId(), $porta->getMaterial()->getId(), $porta->getId()]);

            return "";

        } catch(PDOException $e) {
            $erro = "Erro ao salvar a porta. Tente novamente.";
            if(AMB_DEV)
                $erro .= "<br>" . $e->getMessage();
            return $erro;
        }
    }

    public function excluir($id) {
        try {
            $sql = "DELETE FROM portas WHERE id = ?";

            $conn = Connection::getConnection();
            $stm = $conn->prepare($sql);
            $stm->execute([$id]);
            return "";

        } catch (PDOException $e) {
            $erro = "Erro ao excluir a porta. Tente novamente.";
            if (AMB_DEV) 
                $erro .= "<br>" . $e->getMessage();
            return $erro;
        }
    }

    private function map(array $dados) {
    $portas = array();
        foreach ($dados as $d) {

            $porta = new Porta();
            $porta->setId($d['id']);
            $porta->setModelo($d['modelo']);
            $porta->setCor($d['cor']);
            $porta->setAcessorio($d['acessorio']);

            $sistema = new Sistema();
            $sistema->setId($d["id_sistema"]);
            $sistema->setNome($d["nome_sistema"]);
            $porta->setSistema($sistema);

            $material = new Material();
            $material->setId($d["id_material"]);
            $material->setNome($d["nome_material"]);
            $porta->setMaterial($material);

            array_push($portas, $porta);
            
        }

    return $portas;

    }

}