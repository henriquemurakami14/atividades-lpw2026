<?php

require_once(__DIR__."/../model/Porta.php");
require_once(__DIR__."/../util/Conexao.php");

class SistemaDAO {

    public function listar() {
        $sql = "SELECT * FROM `sistemas`";

        $stmt = Connection::getConnection()->prepare($sql);
        $stmt->execute();

        $dados = $stmt->fetchAll();

        return $this->map($dados);
    }

    private function map(array $dados) {
        $sistemas = array();
        foreach ($dados as $dado) {
            $sistema = new Sistema();
            $sistema->setId($dado["id"]);
            $sistema->setNome($dado["nome"]);

            array_push($sistemas, $sistema);
        }

        return $sistemas;
    }
}