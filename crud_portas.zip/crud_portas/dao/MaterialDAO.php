<?php

require_once(__DIR__."/../model/Porta.php");
require_once(__DIR__."/../util/Conexao.php");

class MaterialDAO {

    public function listar() {
        $sql = "SELECT * FROM `materiais`";

        $stmt = Connection::getConnection()->prepare($sql);
        $stmt->execute();

        $dados = $stmt->fetchAll();

        return $this->map($dados);
    }

    private function map(array $dados) {
        $materiais = array();
        foreach ($dados as $dado) {
            $material = new Material();
            $material->setId($dado["id"]);
            $material->setNome($dado["nome"]);

            array_push($materiais, $material);
        }

        return $materiais;
    }
}