<?php
    require_once(__DIR__ . "/view/include/header.php");
    require_once(__DIR__ . "/view/include/menu.php");
?>

<style>
    .card-porta {
        border: none;
        border-radius: 10px;
        overflow: hidden;
        box-shadow: 0 3px 10px rgba(0, 0, 0, 0.08);
        transition: transform 0.2s ease, box-shadow 0.2s ease;
        height: 100%;
    }

    .card-porta:hover {
        transform: translateY(-6px);
        box-shadow: 0 10px 20px rgba(18, 35, 61, 0.2);
    }

    .card-porta img {
        height: 100%;
        object-fit: contain;
        background-color: #f0efe9;
        padding: 1.5rem;
    }

    .card-porta .card-title {
        color: #12233d;
        font-weight: 700;
    }

    .card-porta .btn-cielo {
        background-color: #12233d;
        color: #ffffff;
        border: none;
        font-weight: 500;
    }

    .card-porta .btn-cielo:hover {
        background-color: #1e3a5f;
        color: #ffffff;
    }
</style>


<div class="row mt-4 mb-5 g-4 justify-content-center">

    <div class="col-6 col-md-4">
        <div class="card card-porta text-center">
            <img src="<?= BASE_URL ?>/img/20250106_162352.jpg" alt="Inserir Porta">
            <div class="card-body d-flex flex-column">
                <h5 class="card-title">Inserir</h5>
                <p class="card-text text-muted small">Cadastre uma nova porta.</p>
                <a href="<?= BASE_URL ?>/view/portas/inserir.php" class="btn btn-cielo mt-auto">Inserir Porta</a>
            </div>
        </div>
    </div>

    <div class="col-6 col-md-4">
        <div class="card card-porta text-center">
            <img src="<?= BASE_URL ?>/img/20250627_144543.jpg" alt="Alterar Porta">
            <div class="card-body d-flex flex-column">
                <h5 class="card-title">Alterar</h5>
                <p class="card-text text-muted small">Edite os dados de uma porta já cadastrada.</p>
                <a href="<?= BASE_URL ?>/view/portas/listar.php" class="btn btn-cielo mt-auto">Alterar Porta</a>
            </div>
        </div>
    </div>

    <div class="col-6 col-md-4">
        <div class="card card-porta text-center">
            <img src="<?= BASE_URL ?>/img/20251119_153809.jpg" alt="Excluir Porta">
            <div class="card-body d-flex flex-column">
                <h5 class="card-title">Excluir</h5>
                <p class="card-text text-muted small">Remova uma porta do catálogo.</p>
                <a href="<?= BASE_URL ?>/view/portas/listar.php" class="btn btn-cielo mt-auto">Excluir Porta</a>
            </div>
        </div>
    </div>


</div>

<?php
    require_once(__DIR__ . "/view/include/footer.php");
?>