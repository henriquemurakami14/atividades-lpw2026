<?php

require_once(__DIR__ . "/Material.php");
require_once(__DIR__ . "/Sistema.php");

class Porta {

    //Atributos
    private ?int $id;
    private ?string $modelo;
    private ?string $cor;
    private ?string $acessorio;
    private ?Sistema $sistema;
    private ?Material $material;

    //GETs e SETs
    
    /**
     * Get the value of id
     */
    public function getId(): ?int
    {
        return $this->id;
    }

    /**
     * Set the value of id
     */
    public function setId(?int $id): self
    {
        $this->id = $id;

        return $this;
    }

    /**
     * Get the value of modelo
     */
    public function getModelo(): ?string
    {
        return $this->modelo;
    }

    /**
     * Set the value of modelo
     */
    public function setModelo(?string $modelo): self
    {
        $this->modelo = $modelo;

        return $this;
    }

    /**
     * Get the value of cor
     */
    public function getCor(): ?string
    {
        return $this->cor;
    }

    /**
     * Set the value of cor
     */
    public function setCor(?string $cor): self
    {
        $this->cor = $cor;

        return $this;
    }

    /**
     * Get the value of acessorio
     */
    public function getAcessorio(): ?string
    {
        return $this->acessorio;
    }

    /**
     * Set the value of acessorio
     */
    public function setAcessorio(?string $acessorio): self
    {
        $this->acessorio = $acessorio;

        return $this;
    }

    /**
     * Get the value of sistema
     */
    public function getSistema(): ?Sistema
    {
        return $this->sistema;
    }

    /**
     * Set the value of sistema
     */
    public function setSistema(?Sistema $sistema): self
    {
        $this->sistema = $sistema;

        return $this;
    }

    /**
     * Get the value of material
     */
    public function getMaterial(): ?Material
    {
        return $this->material;
    }

    /**
     * Set the value of material
     */
    public function setMaterial(?Material $material): self
    {
        $this->material = $material;

        return $this;
    }
}